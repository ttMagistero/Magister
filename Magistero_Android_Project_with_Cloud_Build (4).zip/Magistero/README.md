# Magistero — Android SMS app

Starter Android Studio project for a Xiaomi Redmi 13 with one SIM.

## Features
- Manually enter a phone number and message.
- Confirmation dialog before every SMS.
- Sends through the phone's active/default SIM using Android `SmsManager`.
- Saves contacts locally inside the app.
- Keeps a local history of the last 50 send requests.
- Requests the SMS permission at runtime.

## Build
1. Install Android Studio (current stable) on a computer.
2. Open this `Magistero` folder in Android Studio.
3. Let Gradle sync. Use JDK 17.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the resulting APK on the Redmi 13.

## Important notes
- This project is a starter source project; it has not been built or tested on a physical Redmi 13 in this environment.
- The app sends SMS only after the user presses Send and confirms the recipient.
- Android/operator settings and SIM balance/network determine whether a message can be sent.
- "Sent" means the phone/operator accepted the send request; it does not guarantee delivery.
- SMS charges may apply.
- Use only for recipients who have agreed to receive messages. Do not use it for spam or harassment.
- Android/Google Play restricts SMS permissions for apps distributed through Google Play. This project is intended for personal testing/sideloading; publishing may require eligibility and policy review.


## Build APK in the cloud using GitHub (can be done from a phone)
1. Create a new empty repository on GitHub.
2. Upload the contents of this project ZIP to the repository (including the hidden `.github` folder).
3. Open the repository's **Actions** tab and select **Build Magistero APK**.
4. Run the workflow with **Run workflow** (or wait for the automatic build after pushing to `main`).
5. When the run finishes, open it and download the **Magistero-debug-apk** artifact.
6. Extract the artifact ZIP; it contains `app-debug.apk`. Open it on the Redmi 13 to install.

The APK produced by this workflow is a debug build signed with Android's debug key. It is suitable for personal testing, not Play Store release.
