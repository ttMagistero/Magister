package com.magistero.sms

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var phoneInput: EditText
    private lateinit var nameInput: EditText
    private lateinit var messageInput: EditText
    private lateinit var statusText: TextView
    private lateinit var contactsButton: Button
    private lateinit var historyButton: Button
    private val prefs by lazy { getSharedPreferences("magistero_data", MODE_PRIVATE) }
    private val requestSmsPermission = 410

    private val smsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val result = when (resultCode) {
                Activity.RESULT_OK -> "SMS передано оператору"
                SmsManager.RESULT_ERROR_GENERIC_FAILURE -> "Ошибка отправки"
                SmsManager.RESULT_ERROR_NO_SERVICE -> "Нет сети оператора"
                SmsManager.RESULT_ERROR_RADIO_OFF -> "Радиомодуль выключен"
                SmsManager.RESULT_ERROR_NULL_PDU -> "Ошибка формирования SMS"
                else -> "Не удалось отправить SMS (код $resultCode)"
            }
            runOnUiThread { statusText.text = result }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        val filter = IntentFilter(ACTION_SMS_SENT)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(smsReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(smsReceiver, filter)
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(smsReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            setBackgroundColor(Color.rgb(8, 4, 18))
        }
        val scroll = ScrollView(this).apply { addView(page) }

        page.addView(ImageView(this).apply {
            setImageResource(R.drawable.magistero_avatar)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Аватар Magistero"
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(18).toFloat()
                setStroke(dp(2), Color.rgb(190, 55, 255))
            }
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(-1, dp(220)).apply {
                bottomMargin = dp(14)
            }
        })
        page.addView(TextView(this).apply {
            text = "MAGISTERO  •  SMS CONTROL"
            textSize = 12f
            setTextColor(Color.rgb(218, 150, 255))
            gravity = Gravity.CENTER
            letterSpacing = 0.16f
            setPadding(0, 0, 0, dp(18))
        })

        nameInput = edit("Имя контакта (необязательно)", false)
        phoneInput = edit("Номер телефона, например +79991234567", true)
        messageInput = edit("Текст сообщения", false).apply {
            minLines = 4
            gravity = Gravity.TOP or Gravity.START
        }
        page.addView(nameInput)
        page.addView(phoneInput)
        page.addView(messageInput)

        val send = button("ОТПРАВИТЬ SMS")
        send.setOnClickListener { confirmAndSend() }
        page.addView(send)

        statusText = TextView(this).apply {
            text = "SMS отправляются с основной SIM-карты телефона."
            textSize = 13f
            setTextColor(Color.rgb(220, 194, 240))
            setPadding(0, dp(14), 0, dp(14))
        }
        page.addView(statusText)

        contactsButton = button("СОХРАНИТЬ КОНТАКТ")
        contactsButton.setOnClickListener { saveContact() }
        page.addView(contactsButton)

        val contacts = button("МОИ КОНТАКТЫ")
        contacts.setOnClickListener { showContacts() }
        page.addView(contacts)

        historyButton = button("ИСТОРИЯ ОТПРАВОК")
        historyButton.setOnClickListener { showHistory() }
        page.addView(historyButton)

        page.addView(TextView(this).apply {
            text = "Отправляй сообщения только людям, которые согласились их получать. Возможны тарифы оператора за SMS."
            textSize = 11f
            setTextColor(Color.rgb(156, 124, 185))
            setPadding(0, dp(20), 0, 0)
        })

        setContentView(scroll)
    }

    private fun edit(hintText: String, phone: Boolean): EditText =
        EditText(this).apply {
            hint = hintText
            textSize = 15f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(156, 124, 185))
            inputType = if (phone) InputType.TYPE_CLASS_PHONE
                        else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(28, 12, 48))
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.rgb(117, 42, 174))
            }
            val lp = LinearLayout.LayoutParams(-1, if (phoneHint(hintText)) dp(56) else -2)
            lp.bottomMargin = dp(12)
            layoutParams = lp
        }

    private fun phoneHint(s: String) = s.startsWith("Номер")

    private fun button(label: String) = Button(this).apply {
        text = label
        textSize = 13f
        setTextColor(Color.WHITE)
        isAllCaps = false
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.rgb(139, 35, 220))
            cornerRadius = dp(12).toFloat()
        }
        val lp = LinearLayout.LayoutParams(-1, dp(52))
        lp.bottomMargin = dp(10)
        layoutParams = lp
    }

    private fun confirmAndSend() {
        val phone = phoneInput.text.toString().trim()
        val message = messageInput.text.toString().trim()
        if (phone.length < 7 || message.isBlank()) {
            statusText.text = "Укажи корректный номер и текст сообщения."
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Подтвердить отправку?")
            .setMessage("Обычное SMS будет отправлено на:\n$phone\n\nОтправить сейчас?")
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Отправить") { _, _ -> sendSms(phone, message) }
            .show()
    }

    private fun sendSms(phone: String, message: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.SEND_SMS), requestSmsPermission
            )
            statusText.text = "Разреши Magistero отправлять SMS. Затем нажми «Отправить SMS» ещё раз."
            return
        }
        try {
            val manager = if (Build.VERSION.SDK_INT >= 23) getSystemService(SmsManager::class.java)
                          else @Suppress("DEPRECATION") SmsManager.getDefault()
            val parts = manager.divideMessage(message)
            val sentIntents = ArrayList<PendingIntent>()
            for (i in parts.indices) {
                val intent = Intent(ACTION_SMS_SENT).setPackage(packageName)
                sentIntents.add(
                    PendingIntent.getBroadcast(
                        this, 1000 + i, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                )
            }
            if (parts.size > 1) {
                manager.sendMultipartTextMessage(phone, null, parts, sentIntents, null)
            } else {
                manager.sendTextMessage(phone, null, message, sentIntents.first(), null)
            }
            addHistory(phone, message, "Передано на отправку")
            statusText.text = "Запрос на отправку передан телефону. Доставка зависит от оператора."
            messageInput.text.clear()
        } catch (e: Exception) {
            statusText.text = "Не удалось отправить: ${e.localizedMessage ?: "проверь SIM и сеть"}"
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestSmsPermission) {
            statusText.text = if (grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED)
                "Разрешение получено. Нажми «Отправить SMS» ещё раз."
            else "Разрешение на отправку SMS не предоставлено."
        }
    }

    private fun saveContact() {
        val name = nameInput.text.toString().trim()
        val phone = phoneInput.text.toString().trim()
        if (name.isBlank() || phone.length < 7) {
            statusText.text = "Для сохранения контакта введи имя и номер."
            return
        }
        val array = readContacts()
        val item = JSONObject().put("name", name).put("phone", phone)
        array.put(item)
        prefs.edit().putString("contacts", array.toString()).apply()
        statusText.text = "Контакт сохранён в Magistero."
        nameInput.text.clear()
    }

    private fun readContacts(): JSONArray =
        try { JSONArray(prefs.getString("contacts", "[]")) } catch (_: Exception) { JSONArray() }

    private fun showContacts() {
        val array = readContacts()
        if (array.length() == 0) {
            AlertDialog.Builder(this).setMessage("Пока нет сохранённых контактов.")
                .setPositiveButton("ОК", null).show()
            return
        }
        val labels = (0 until array.length()).map {
            val obj = array.getJSONObject(it)
            "${obj.optString("name")} — ${obj.optString("phone")}"
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Выбери контакт").setItems(labels) { _, which ->
            phoneInput.setText(array.getJSONObject(which).optString("phone"))
            nameInput.setText(array.getJSONObject(which).optString("name"))
        }.setNegativeButton("Закрыть", null).show()
    }

    private fun addHistory(phone: String, message: String, state: String) {
        val array = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        array.put(JSONObject().put("phone", phone).put("message", message).put("state", state))
        while (array.length() > 50) array.remove(0)
        prefs.edit().putString("history", array.toString()).apply()
    }

    private fun showHistory() {
        val array = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        if (array.length() == 0) {
            AlertDialog.Builder(this).setMessage("История пока пуста.")
                .setPositiveButton("ОК", null).show()
            return
        }
        val lines = (0 until array.length()).reversed().map {
            val obj = array.getJSONObject(it)
            "Кому: ${obj.optString("phone")}\n${obj.optString("message")}\nСтатус: ${obj.optString("state")}"
        }
        AlertDialog.Builder(this).setTitle("История отправок")
            .setItems(lines.toTypedArray(), null)
            .setPositiveButton("Закрыть", null).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val ACTION_SMS_SENT = "com.magistero.sms.ACTION_SMS_SENT"
    }
}
